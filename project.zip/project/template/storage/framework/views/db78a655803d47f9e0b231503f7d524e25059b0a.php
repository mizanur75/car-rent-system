<?php $__env->startSection('content'); ?>

<div class="card-authentication2 mx-auto my-5">
        <div class="card-group shadow-lg">
            <div class="card mb-0">
                <div class="card-body">
                    <div class="card-content p-3">
                     <div class="card-title text-uppercase text-center pb-3">Sign In</div>
                       <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                          <div class="form-group">
                           <div class="position-relative has-icon-left">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Email Address">

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                 <div class="form-control-position">
                                    <i class="icon-user"></i>
                                </div>
                           </div>
                          </div>
                          <div class="form-group">
                           <div class="position-relative has-icon-left">
                              <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password">

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                              <div class="form-control-position">
                                  <i class="icon-lock"></i>
                              </div>
                           </div>
                          </div>
                          <div class="form-row mr-0 ml-0">
                          <div class="form-group col-6">
                              <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>
                            <div class="form-group col-6 text-right">
                             <a href="">Reset Password</a>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary shadow-primary btn-block waves-effect waves-light">Sign In</button>
                         <div class="text-center pt-3">
                        <p>or Sign in with</p>
                        <a href="javascript:void()" class="btn-social-text btn-facebook waves-effect waves-light m-1"><i class="fa fa-facebook-square"></i> <span>facebook</span></a>
                        <a href="javascript:void()" class="btn-social-text btn-google-plus waves-effect waves-light m-1"><i class="fa fa-google-plus"></i> <span>google+</span></a>
                            <hr>
                        <p class="text-muted">Do not have an account? <a href="authentication-signup2.html"> Sign Up here</a></p>
                        </div>
                    </form>
                 </div>
               </div>
            </div>
              <div class="card mb-0">
                <div class="bg-signin2"></div>
                    <div class="card-img-overlay rounded-left my-5">
                     <h2 class="text-white">EchoSan</h2>
                     <h1 class="text-white">Web Based It Firm</h1>
                     <p class="card-text text-white pt-3">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                  </div>
              </div>
           </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>